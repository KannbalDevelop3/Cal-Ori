<?php

require_once ("conex.php");

class modelo_login {

  private $myConex;
  private $enlaceDB;

  function __construct() {
    $this->myConex = new Conexion();
    $this->enlaceDB = $this->myConex->conectarse();
  }

  function login_usu() {
    $form_data = array(
        ':email_usu' => $_POST['txt_email_usu'],
        ':password' => sha1($_POST['txt_password'])
    );
    $query = "SELECT count(*) as Total_Usu "
            . "FROM tbl_usuarios WHERE "
            . "vc_emaill =  '" . $form_data[':email_usu'] . "' AND vc_password ='" . $form_data[':password'] . "'"
            . "AND bool_activo = '1'";
    $result = mysqli_query($this->enlaceDB, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['Total_Usu'];
    if ($count > 0) {
      $myMsg = array('iniciar_sesion' => '1');
      $usu_data = $this->get_usu_data($form_data);
      $data[] = $myMsg + array_pop($usu_data);
    } else {
      $data[] = array('iniciar_sesion' => '0');
    }
    return $data;
  }

  function get_usu_data($ptrFormData) {
    $query = "SELECT id_usuario,vc_nombre,vc_apellido,vc_emaill,vc_sexo,int_edad,id_rol,vc_peso,vc_altura,vc_imc,vc_enfermedades,vc_respuestasCuest FROM tbl_usuarios WHERE vc_emaill =  '" . $ptrFormData[':email_usu'] . "' AND bool_activo = '1'";

    $statement = mysqli_query($this->enlaceDB, $query);
    while ($data[] = mysqli_fetch_assoc($statement)) {
      //
    }
    array_pop($data);
    return $data;
  }

  function existe_usu($ptrFormData) {
    $query = "SELECT count(*) as Total_Usu FROM tbl_usuarios WHERE vc_emaill =  '" . $ptrFormData[':email'] . "' ";
    $result = mysqli_query($this->enlaceDB, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['Total_Usu'];
    return $count;
  }

  function registrar_usu() {
    $form_data = array(
        ':nombre' => $_POST["txt_nombre"],
        ':apellido' => $_POST["txt_apellido"],
        ':email' => $_POST["txt_email"],
        ':contrasenia' => sha1($_POST["txt_password"])
    );
    $existe_usuario = $this->existe_usu($form_data);
    if ($existe_usuario == 1) {
      $data[] = array('usuario_registrado' => '0', 'mensaje' => 'ya existe un usuario con ese correo electronico');
    } else {
      $query = "INSERT INTO tbl_usuarios (vc_nombre,vc_apellido,vc_emaill,vc_password) VALUES  "
              . "('" . $form_data[':nombre'] .
              "','" . $form_data[':apellido'] .
              "','" . $form_data[':email'] .
              "','" . $form_data[':contrasenia'] . "')";
      $statement = mysqli_query($this->enlaceDB, $query);
      if ($statement) {
        $data[] = array('usuario_registrado' => '1', 'mensaje' => 'Usuario Registrado exitosamente');
      } else {
        $data[] = array('usuario_registrado' => '0', 'mensaje' => 'Error');
      }
    }
    return $data;
  }

  function update_reg_usu() {
    $form_data = array(
        ':email' => $_POST["txt_email"],
        ':sexo' => $_POST["txt_sexo"],
        ':edad' => $_POST["txt_edad"],
        ':peso' => $_POST["txt_peso"],
        ':altura' => $_POST["txt_altura"],
        ':imc' => $_POST["txt_imc"],
        ':enfermedad' => $_POST["txt_enfermedades"],
        ':respuestasCuest' => $_POST["txt_respuestasCuest"]
    );
    $query = "UPDATE tbl_usuarios SET"
            . " vc_sexo = '" . $form_data[':sexo'] .
            "' , int_edad = " . $form_data[':edad'] .
            " , vc_peso = " . $form_data[':peso'] .
            " , vc_altura = " . $form_data[':altura'] .
            " , vc_imc = " . $form_data[':imc'] .
            " , vc_enfermedades = '" . $form_data[':enfermedad'] .
            "' , vc_respuestasCuest = '" . $form_data[':respuestasCuest'] .
            "' WHERE vc_emaill = '" . $form_data[':email'] . "'";

    $statement = mysqli_query($this->enlaceDB, $query);
    if ($statement) {
      $data[] = array('exito' => '1');
    } else {
      $data[] = array('exito' => '0');
    }
    return $data;
  }

}
