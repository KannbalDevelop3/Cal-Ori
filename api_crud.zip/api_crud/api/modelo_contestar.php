<?php

require_once ("conex.php");

class modelo_contestar {

  private $myConex;
  private $enlaceDB;

  function __construct() {
    $this->myConex = new Conexion();
    $this->enlaceDB = $this->myConex->conectarse();
  }

  function existe_contestar() {
    $form_data = array(':email_usu' => $_POST['str_email_usu'], ':id_act' => $_POST['str_id_act'],':id_rol' => $_POST['str_id_rol']);
    $queryExiste = "SELECT count(*) as Total_Contestar FROM rel_contestar  "
            . "WHERE email_usuario = '" . $form_data[':email_usu'] . "' AND id_rol= '" . $form_data[':id_rol'] . "' AND id_actividad = '" . $form_data[':id_act'] . "'";
    $result = mysqli_query($this->enlaceDB, $queryExiste);
    $row = mysqli_fetch_array($result);
    $count = $row['Total_Contestar'];

    if ($count > 0) {
      //$data[] = array('contestar_existe' => '1');
    $queryData = "SELECT * FROM   rel_contestar "
    . "WHERE email_usuario = '" . $form_data[':email_usu'] . "' AND id_rol= '" . $form_data[':id_rol'] . "' AND id_actividad = '" . $form_data[':id_act'] . "'";
    $statement = mysqli_query($this->enlaceDB, $queryData);
    while ($data[] = mysqli_fetch_assoc($statement)) {
      //
    }
    array_pop($data);
    $myMsg = array('contestar_existe' => '1');
    $data[] = $myMsg + array_pop($data);
    } else {
      $data[] = array('contestar_existe' => '0');
    }
    return $data;
  }

  function crear_contestar() {
     $form_data = array(
        ':email_usu' => $_POST['str_email_usu'],
        ':id_act' => $_POST['str_id_act'],
        ':id_rol' => $_POST['str_id_rol'],
        ':val_avance' => $_POST['int_avance'],
        ':str_data' => $_POST['str_data'],
        ':val_estatus' => $_POST['txt_status']
    );

    if ($form_data[":val_estatus"]== NULL) {
      $form_data[":val_estatus"] = "incomplete";
    }

    $query = "SELECT count(*) as Total_Contestar FROM rel_contestar  "
            . "WHERE email_usuario = '" . $form_data[':email_usu'] . "' AND id_rol= '" . $form_data[':id_rol'] . "' AND id_actividad = '" . $form_data[':id_act'] . "'";
    $result = mysqli_query($this->enlaceDB, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['Total_Contestar'];
	
	$query="";
	if ($count > 0) {
      $data1[] = array('exito' => '0','mensaje' => 'El registro ya existe');
      $queryUpdate = "UPDATE rel_contestar SET "
      . "int_avance='" . $form_data[':val_avance'] .
      "',str_saveData='" . $form_data[':str_data'] .
      "',vc_estatus='" . $form_data[':val_estatus'] .
      "' WHERE email_usuario = '" . $form_data[':email_usu'] .
      "' AND id_actividad = '" . $form_data[':id_act'] .
      "' AND id_rol = '" . $form_data[':id_rol'] . "'";
      $statement = mysqli_query($this->enlaceDB, $queryUpdate);
      if ($statement) {
        $data2[] = array('exito' => '1','mensaje'=>'Información Actualizada');
        $data= array_merge($data1, $data2);
      } else {
        $data2[] = array('exito' => '0','mensaje'=>'Error en la inserción de registro');
        $data = $data1 + $data2;
      }
    } else {		
		    $query = "INSERT INTO rel_contestar(email_usuario, id_actividad,id_rol,int_avance,str_saveData) VALUES  "
            . "('" . $form_data[':email_usu'] . "','" . $form_data[':id_act'] . "','" . $form_data[':id_rol'] . "','" . $form_data[':val_avance'] . "','" . $form_data[':str_data'] . "')";
    $statement = mysqli_query($this->enlaceDB, $query);
    if ($statement) {
      $data[] = array('exito' => '1','mensaje'=>'Alta exitosa');
    } else {
      $data[] = array('exito' => '0','mensaje'=>'error en la inserción de registro');
    }
    }
    return $data;
  }


  function update_contestar() {
    $form_data = array(
        ':email_usu' => $_POST['str_email_usu'],
        ':id_act' => $_POST['str_id_act'],
        ':id_rol' => $_POST['str_id_rol'],
        ':val_avance' => $_POST['int_avance'],
        ':str_data' => $_POST['str_data'],
        ':val_estatus' => $_POST['txt_status']
    );
    $queryUpdate = "UPDATE rel_contestar SET "
            . "int_avance='" . $form_data[':val_avance'] .
            "',str_saveData='" . $form_data[':str_data'] .
            "',vc_estatus='" . $form_data[':val_estatus'] .
            "' WHERE email_usuario = '" . $form_data[':email_usu'] .
            "' AND id_actividad = '" . $form_data[':id_act'] .
            "' AND id_rol = '" . $form_data[':id_rol'] . "'";
    $statement = mysqli_query($this->enlaceDB, $queryUpdate);
    if ($statement) {
      $data[] = array('exito' => '1');
    } else {
      $data[] = array('exito' => '0');
    }
    return $data;
  }

}
