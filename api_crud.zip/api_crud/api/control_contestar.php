<?php

require_once('header_cors.php');
require_once('modelo_contestar.php');
require_once('api_auth.php');

require_auth();

$api_object = new modelo_contestar();

if ($_GET["action"] == 'existe_contestar') {
  $data = $api_object->existe_contestar();
}
if ($_GET["action"] == 'crear_contestar') {
  $data = $api_object->crear_contestar();
}
if ($_GET["action"] == 'update_contestar') {
  $data = $api_object->update_contestar();
}
echo json_encode($data);
?>