<?php

require_once ("conex.php");

class modelo_usuario {

  private $myConex;
  private $enlaceDB;

  function __construct() {
    $this->myConex = new Conexion();
    $this->enlaceDB = $this->myConex->conectarse();
  }

  function fetch_all() {
    $query = "SELECT id_usuario,vc_nombre,vc_apellido,vc_emaill  FROM tbl_usuarios WHERE  bool_activo = '1' ORDER BY id_usuario ";
    $statement = mysqli_query($this->enlaceDB, $query);
    while ($data[] = mysqli_fetch_assoc($statement)) {
      //
    }
    array_pop($data);
    return $data;
  }

  function fetch_all_pag() {
    $form_data = array(':intInicio' => $_POST["int_Inicio"], ':IntRegPag' => $_POST["int_RegPag"]);
    $query = "SELECT id_usuario,vc_nombre,vc_apellido,vc_emaill FROM tbl_usuarios  WHERE  bool_activo = '1' ORDER BY id_usuario ASC LIMIT  " . $form_data[':intInicio'] . "," . $form_data[':IntRegPag'];
    $statement = mysqli_query($this->enlaceDB, $query);
    while ($data[] = mysqli_fetch_assoc($statement)) {
      //
    }
    array_pop($data);
    return $data;
  }

  function total_usuarios() {
    $query = "SELECT count(*) as Total_Usu FROM tbl_usuarios ";
    $statement = mysqli_query($this->enlaceDB, $query);
    while ($data[] = mysqli_fetch_assoc($statement)) {
      //
    }
    array_pop($data);
    return $data;
  }

  function fetch_single() {
    $form_data = array(':id' => $_POST['id_usu']);
    $query = "SELECT * FROM tbl_usuarios WHERE id_usuario = '" . $_POST['id_usu'] . "' AND bool_activo = '1'";
    $statement = mysqli_query($this->enlaceDB, $query);
    while ($data[] = mysqli_fetch_assoc($statement)) {
      //
    }
    array_pop($data);
    return $data;
  }

  function fetch_single_mail() {
    $form_data = array(':email' => $_POST['email_usu']);
    $query = "SELECT id_usuario,vc_nombre,vc_apellido,vc_emaill,vc_sexo,int_edad,vc_rol,vc_peso,vc_altura,vc_enfermedades FROM tbl_usuarios WHERE vc_emaill =  '" . $form_data[':email'] . "' AND bool_activo = '1'";
    $statement = mysqli_query($this->enlaceDB, $query);
    while ($data[] = mysqli_fetch_assoc($statement)) {
      //
    }
    array_pop($data);
    return $data;
  }

  function insert() {
    $form_data = array(
        ':nombre' => $_POST["txt_nombre"],
        ':apellido' => $_POST["txt_apellido"],
        ':email' => $_POST["txt_email"],
        ':contrasenia' => sha1($_POST["txt_password"]),
        ':sexo' => $_POST["txt_sexo"],
        ':anioNac' => $_POST["str_anioNac"],
        ':peso' => $_POST["txt_peso"],
        ':altura' => $_POST["txt_altura"],
        ':rol' => $_POST["txt_rol"],
        ':enfermedad' => $_POST["str_enfermedades"]
    );
    $query = "INSERT INTO tbl_usuarios (vc_nombre,vc_apellido,vc_emaill,vc_password,vc_sexo,vc_anio_nacimiento,vc_rol,vc_peso,vc_altura,vc_enfermedades) VALUES  "
            . "('" . $form_data[':nombre'] .
            "','" . $form_data[':apellido'] .
            "','" . $form_data[':email'] .
            "','" . $form_data[':contrasenia'] .
            "','" . $form_data[':sexo'] .
            "','" . $form_data[':anioNac'] .
            "','" . $form_data[':rol'] .
            "','" . $form_data[':peso'] .
            "','" . $form_data[':altura'] .
            "','" . $form_data[':enfermedad'] . "')";
    $statement = mysqli_query($this->enlaceDB, $query);
    if ($statement) {
      $data[] = array('exito' => '1');
    } else {
      $data[] = array('exito' => '0');
    }
    return $data;
  }

  function update() {
    if ($_POST["txt_password"] != NULL) {
      $form_data = array(
          ':id' => $_POST["val_id"],
          ':nombre' => $_POST["txt_nombre"],
          ':apellido' => $_POST["txt_apellido"],
          ':email' => $_POST["txt_email"],
          ':contrasenia' => sha1($_POST["txt_password"]),
          ':sexo' => $_POST["txt_sexo"],
          ':peso' => $_POST["txt_peso"],
          ':altura' => $_POST["txt_altura"],
          ':rol' => $_POST["txt_rol"]
      );
      $query = "UPDATE tbl_usuarios SET"
              . " vc_nombre = '" . $form_data[':nombre'] .
              "' , vc_apellido = '" . $form_data[':apellido'] .
              "' , vc_emaill = '" . $form_data[':email'] .
              "' , vc_password = '" . $form_data[':contrasenia'] .
              "' , vc_sexo = '" . $form_data[':sexo'] .
              "' , vc_peso = '" . $form_data[':peso'] .
              "' , vc_altura = '" . $form_data[':altura'] .
              "' , vc_rol = '" . $form_data[':rol'] .
              "' WHERE id_usuario = '" . $form_data[':id'] . "'";
    } else {
      $form_data = array(
          ':id' => $_POST["val_id"],
          ':nombre' => $_POST["txt_nombre"],
          ':apellido' => $_POST["txt_apellido"],
          ':email' => $_POST["txt_email"],
          ':sexo' => $_POST["txt_sexo"],
          ':peso' => $_POST["txt_peso"],
          ':altura' => $_POST["txt_altura"],
          ':rol' => $_POST["txt_rol"]
      );
      $query = "UPDATE tbl_usuarios SET"
              . " vc_nombre = '" . $form_data[':nombre'] .
              "' , vc_apellido = '" . $form_data[':apellido'] .
              "' , vc_emaill = '" . $form_data[':email'] .
              "' , vc_sexo = '" . $form_data[':sexo'] .
              "' , vc_peso = '" . $form_data[':peso'] .
              "' , vc_altura = '" . $form_data[':altura'] .
              "' , vc_rol = '" . $form_data[':rol'] .
              "' WHERE id_usuario = '" . $form_data[':id'] . "'";
    }
    $statement = mysqli_query($this->enlaceDB, $query);
    if ($statement) {
      $data[] = array('exito' => '1');
    } else {
      $data[] = array('exito' => '0');
    }
    return $data;
  }

  function delete() {
    $form_data = array(':id' => $_POST['id']);
    $query = "DELETE FROM tbl_usuarios WHERE id_usuario = '" . $form_data[':id'] . "'";
    $statement = mysqli_query($this->enlaceDB, $query);
    if ($statement) {
      $data[] = array('exito' => '1');
    } else {
      $data[] = array('exito' => '0');
    }
    return $data;
  }

  function off_user() {
    $form_data = array(':id' => $_POST['id']);
    $query = "UPDATE tbl_usuarios SET bool_activo = '0' WHERE id_usuario = '" . $form_data[':id'] . "'";
    $statement = mysqli_query($this->enlaceDB, $query);
    if ($statement) {
      $data[] = array('exito' => '1');
    } else {
      $data[] = array('exito' => '0');
    }
    return $data;
  }

  function existe_usu() {
    $form_data = array(':email_usu' => $_POST['txt_email_usu']);
    $query = "SELECT count(*) as Total_Usu FROM tbl_usuarios WHERE vc_emaill =  '" . $form_data[':email_usu'] . "' ";
    $statement = mysqli_query($this->enlaceDB, $query);
    while ($data[] = mysqli_fetch_assoc($statement)) {
      //
    }
    array_pop($data);
    return $data;
  }

}
