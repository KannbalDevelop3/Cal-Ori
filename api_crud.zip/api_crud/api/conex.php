<?php

class Conexion {

  private $host;
  private $usuario;
  private $password;
  private $baseDatos;

  public function __construct() {
    $this->host = "localhost";
    $this->usuario = "root";
    $this->password = "soportes";
    $this->baseDatos = "sh_nutricion";
  }

  public function conectarse() {
    $enlace = mysqli_connect($this->host, $this->usuario, $this->password, $this->baseDatos);
    if ($enlace) {      
    } else {
      die('Error de Conexión (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
    }
    return $enlace;
  }

  public function desconectarse() {
    mysqli_close($this->enlace);
  }

}

?>