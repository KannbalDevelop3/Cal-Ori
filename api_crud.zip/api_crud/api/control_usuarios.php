<?php

require_once('header_cors.php');
require_once('modelo_usuarios.php');
require_once('api_auth.php');

require_auth();

$api_object = new modelo_usuario();

if ($_GET["action"] == 'fetch_all') {
  $data = $api_object->fetch_all();
}

if ($_GET["action"] == 'fetch_all_pag') {
  $data = $api_object->fetch_all_pag();
}

if ($_GET["action"] == 'total_usuarios') {
  $data = $api_object->total_usuarios();
}

if ($_GET["action"] == 'insert') {
  $data = $api_object->insert();
}

if ($_GET["action"] == 'fetch_single') {
  $data = $api_object->fetch_single();
}

if ($_GET["action"] == 'fetch_single_mail') {
  $data = $api_object->fetch_single_mail();
}

if ($_GET["action"] == 'update') {
  $data = $api_object->update();
}

if ($_GET["action"] == 'delete') {
  $data = $api_object->delete();
}

if ($_GET["action"] == 'off_user') {
  $data = $api_object->off_user();
}

if ($_GET["action"] == 'existe_usu') {
  $data = $api_object->existe_usu();
}

echo json_encode($data);
?>