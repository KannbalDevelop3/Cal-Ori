<?php
require_once('header_cors.php');
require_once('modelo_login.php');

$api_object = new modelo_login();

if ($_GET["action"] == 'login_usu') {
  $data = $api_object->login_usu();
}

if ($_GET["action"] == 'registrar_usu') {
  $data = $api_object->registrar_usu();
}

if ($_GET["action"] == 'update_reg_usu') {
  $data = $api_object->update_reg_usu();
}

echo json_encode($data);
?>