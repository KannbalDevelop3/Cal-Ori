
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE sh_nutricion;
USE sh_nutricion;


--
-- Base de datos: `sh_nutricion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rel_contestar`
--

CREATE TABLE `rel_contestar` (
  `email_usuario` varchar(60) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `id_actividad` varchar(45) NOT NULL,
  `int_avance` int(11) NOT NULL DEFAULT '0',
  `str_saveData` mediumtext,
  `vc_estatus` varchar(45) NOT NULL DEFAULT 'incomplete'
) ENGINE=InnoDB ;

--
-- Volcado de datos para la tabla `rel_contestar`
--

INSERT INTO `rel_contestar` (`email_usuario`, `id_rol`, `id_actividad`, `int_avance`, `str_saveData`, `vc_estatus`) VALUES
('anita.mandarina@demo.com', 1, 'frut_invierno', 3, '0-1-1-1-1', 'incomplete'),
('anita.mandarina@demo.com', 1, 'ebook_Verduras', 4, '1,1,1', 'incomplet'),
('eduardo@gamil.com', 1, 'ebook_Verduras', 0, '0-0-0-0-0-0-0-0', 'incomplete'),
('prueba@gmail.com', 1, 'ebook_Verduras', 9, '1', 'incomplet'),
('prueba@gmail.com', 1, 'ebook_Frutas', 6, '1', 'incomplete'),
('prueba@gmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'incomplet'),
('prueba@gmail.com', 1, 'frut_prim', 1, '1,1,1,1,1', 'incomplet'),
('prueba@gmail.com', 1, 'frut_verano', 1, '1', 'incomplet'),
('prueba@gmail.com', 1, 'verd_invier', 1, '0', 'incomplete'),
('kat@gmail.com', 1, 'verd_invier', 1, '0', 'incomplete'),
('prueba@gmail.com', 1, 'verd_prim', 1, '0', 'incomplete'),
('prueba@gmail.com', 1, 'verd_prim', 1, '0', 'incomplete'),
('kat@gmail.com', 1, 'verd_prim', 1, '0', 'incomplete'),
('popis@gmail.com', 1, 'verd_prim', 1, '1,1', 'incomplet'),
('popis@gmail.com', 1, 'verd_prim', 1, '1,1', 'incomplet'),
('popis@gmail.com', 1, 'verd_invier', 1, '1,1,1', 'incomplet'),
('popis@gmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'incomplet'),
('popis@gmail.com', 1, 'frut_prim', 1, '1,1,1,1,1', 'incomplet'),
('popis@gmail.com', 1, 'frut_verano', 1, '1', 'incomplet'),
('popis@gmail.com', 1, 'ebook_Verduras', 9, '1', 'incomplet'),
('popis@gmail.com', 1, 'ebook_Frutas', 4, '1,1', 'incomplet'),
('daniel@gmail.com', 1, 'ebook_Frutas', 1, '1', 'incomplete'),
('daniel@gmail.com', 1, 'ebook_Verduras', 0, '0', 'incomplete'),
('daniela@gmail.com', 1, 'ebook_Frutas', 0, '0', 'incomplete'),
('daniela@gmail.com', 1, 'ebook_Verduras', 7, '1,1,1,1,1,1', 'incomplet'),
('daniela@gmail.com', 1, 'verd_invier', 1, '1,1,1', 'complete'),
('daniela@gmail.com', 1, 'verd_prim', 1, '1,1', 'complete'),
('daniela@gmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'complete'),
('daniela@gmail.com', 1, 'frut_prim', 1, '1,1,1,1,1', 'complete'),
('daniela@gmail.com', 1, 'frut_verano', 1, '1', 'complete'),
('raul@gmail.com', 1, 'ebook_Frutas', 0, '0', 'incomplete'),
('raul@gmail.com', 1, 'ebook_Verduras', 1, '1', 'incomplet'),
('mafer@gmail.com', 1, 'ebook_Frutas', 41, '1,1,1,1,1,1,1', 'incomplet'),
('mafer@gmail.com', 1, 'ebook_Verduras', 22, '1,1,1,1,1,1,1,1', 'incomplet'),
('pruebas.calori@kannbal.com', 1, 'ebook_Frutas', 30, '1,1,1,1,1,1,1', 'incomplet'),
('pruebas.calori@kannbal.com', 1, 'ebook_Verduras', 20, '1,,1,1,1,1,1,1', 'incomplet'),
('mafer@gmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'incomplete'),
('mafer@gmail.com', 1, 'frut_verano', 1, '1', 'complete'),
('mafer@gmail.com', 1, 'frut_prim', 1, '1,1,1,1,1', 'incomplete'),
('mafer@gmail.com', 1, 'verd_invier', 1, '1,1,1', 'complete'),
('mafer@gmail.com', 1, 'verd_prim', 1, '1,1,1', 'complete'),
('saul@gmail.com', 1, 'ebook_Frutas', 0, '0', 'incomplete'),
('saul@gmail.com', 1, 'ebook_Verduras', 0, '0', 'incomplete'),
('samuel@gmail.com', 1, 'ebook_Frutas', 3, '1,1,1', 'incomplet'),
('samuel@gmail.com', 1, 'ebook_Verduras', 2, '1,1', 'incomplet'),
('marcos@gmail.com', 1, 'ebook_Frutas', 0, '0', 'incomplete'),
('marcos@gmail.com', 1, 'ebook_Frutas', 0, '0', 'incomplete'),
('marcos@gmail.com', 1, 'ebook_Verduras', 0, '0', 'incomplete'),
('manu@gmail.com', 1, 'ebook_Frutas', 39, '1,1,1,1,1,1,1', 'incomplet'),
('manu@gmail.com', 1, 'ebook_Verduras', 37, '1,1,1,1,1,1,1,1', 'incomplet'),
('manu@gmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'complete'),
('manu@gmail.com', 1, 'frut_prim', 1, '1,1,1,1,1', 'complete'),
('manu@gmail.com', 1, 'frut_verano', 1, '1', 'complete'),
('manu@gmail.com', 1, 'verd_invier', 1, '1', 'complete'),
('manu@gmail.com', 1, 'verd_prim', 1, '0,1', 'complete'),
('pruebas.calori@kannbal.com', 1, 'verd_invier', 1, '1,1,1', 'incomplete'),
('pruebas.calori@kannbal.com', 1, 'verd_prim', 1, '1,1,1', 'incomplete'),
('pruebas.calori@kannbal.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'complete'),
('pruebas.calori@kannbal.com', 1, 'frut_prim', 1, '1,1,1,1,1', 'complete'),
('pruebas.calori@kannbal.com', 1, 'frut_verano', 1, '1', 'complete'),
('bot@gmail.com', 1, 'ebook_Frutas', 0, '0', 'incomplete'),
('bot@gmail.com', 1, 'ebook_Verduras', 3, '1,1,1', 'incomplet'),
('anita.mandarina@demo.com', 1, 'ebook_Frutas', 0, '0', 'incomplete'),
('bot@gmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'complete'),
('bot@gmail.com', 1, 'frut_prim', 1, '1,1,1,1,1', 'complete'),
('bot@gmail.com', 1, 'frut_verano', 1, '1', 'complete'),
('sergio.rodriguez@kannbal.com', 1, 'ebook_Frutas', 40, '1,1,1,1,1,1,1', 'incomplet'),
('sergio.rodriguez@kannbal.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'complete'),
('sergio.rodriguez@kannbal.com', 1, 'frut_prim', 1, '1,1,1,1,1', 'complete'),
('sergio.rodriguez@kannbal.com', 1, 'frut_verano', 1, '1', 'complete'),
('sergio.rodriguez@kannbal.com', 1, 'ebook_Verduras', 37, '1,1,1,1,1,1,1,1', 'incomplet'),
('son@gmail.com', 1, 'ebook_Frutas', 5, '1,1,1,1,1', 'incomplet'),
('son@gmail.com', 1, 'ebook_Verduras', 15, '1,1,1,1,1,1,1', 'incomplet'),
('son@gmail.com', 1, 'verd_invier', 1, '1,1,1', 'complete'),
('son@gmail.com', 1, 'verd_prim', 1, '1,1', 'complete'),
('son@gmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'complete'),
('son@gmail.com', 1, 'frut_prim', 1, '1,1,1,1,1', 'complete'),
('son@gmail.com', 1, 'frut_verano', 1, '1', 'complete'),
('liz@gmail.com', 1, 'ebook_Frutas', 5, '1,1,1,1,1', 'incomplet'),
('liz@gmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'complete'),
('midu@gmail.com', 1, 'ebook_Frutas', 4, '1,1,1,1', 'incomplet'),
('midu@gmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'complete'),
('midu@gmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'complete'),
('sergio.rodriguez@kannbal.com', 1, 'verd_invier', 1, '1,1,1', 'complete'),
('sergio.rodriguez@kannbal.com', 1, 'verd_prim', 1, '1,1', 'complete'),
('demora', 1, 'ebook_Frutas', 3, '0,1,1,0,0,1', 'incomplet'),
('alfredo@gmail.com', 1, 'ebook_Frutas', 0, '0', 'incomplete'),
('alfredo@gmail.com', 1, 'ebook_Frutas', 0, '0', 'incomplete'),
('alfredo@gmail.com', 1, 'frut_invierno', 1, '0', 'incomplete'),
('serch_rod@hotmail.com', 1, 'ebook_Frutas', 26, '1,1,1,1,1,1,1', 'incomplet'),
('serch_rod@hotmail.com', 1, 'frut_invierno', 1, '1,1,1,1,1', 'complete'),
('serch_rod@hotmail.com', 1, 'frut_prim', 1, '1,1,1,1,1', 'complete'),
('serch_rod@hotmail.com', 1, 'frut_verano', 1, '1', 'complete'),
('serch_rod@hotmail.com', 1, 'ebook_Verduras', 2, '1,,1', 'incomplet'),
('serch_rod@hotmail.com', 1, 'ebook_Verduras', 2, '1,,1', 'incomplet'),
('alfredo@gmail.com', 1, 'ebook_Verduras', 11, '1,1,1,1,1,1,1', 'incomplet'),
('serch_rod@hotmail.com', 1, 'verd_invier', 1, '1,1,1', 'complete'),
('serch_rod@hotmail.com', 1, 'verd_prim', 1, '1,1', 'complete'),
('demora', 1, 'frut_invierno', 1, '1,1,1', 'incomplete'),
('demora', 1, 'verd_invier', 1, '0', 'incomplete'),
('demora', 1, 'verd_prim', 1, '1', 'incomplete'),
('demora', 1, 'frut_prim', 1, '0', 'incomplete'),
('doc.calori@kannbal.com', 1, 'ebook_Frutas', 0, '0', 'incomplete'),
('prueba@kannbal.com', 1, 'ebook_Frutas', 5, '1,1,1,1,1', 'incomplet'),
('prueba@kannbal.com', 1, 'frut_invierno', 1, '1,0,0,1', 'incomplete');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_actividad`
--

CREATE TABLE `tbl_actividad` (
  `id_actividad` varchar(45) NOT NULL,
  `vc_nomb_actividad` varchar(45) DEFAULT NULL,
  `vc_descripcion` varchar(255) DEFAULT NULL,
  `bool_activo` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB ;

--
-- Volcado de datos para la tabla `tbl_actividad`
--

INSERT INTO `tbl_actividad` (`id_actividad`, `vc_nomb_actividad`, `vc_descripcion`, `bool_activo`) VALUES
('ebook_Frutas', 'Nutrición', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit', 1),
('ebook_Verduras', 'Ebook Verduras', 'Sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.', 1),
('frut_invierno', 'Frutas Invierno', 'Lorem Ibsum', 1),
('frut_otonio', 'Frutas Otoño', 'Lorem Ibsum', 1),
('frut_prim', 'Frutas Primavera', 'Lorem Ibsum', 1),
('frut_retos', 'Juegos Frutas', 'Lorem Ibsum', 1),
('frut_verano', 'Frutas Verano', 'Lorem Ibsum', 1),
('verd_invier', 'Verduras Primavera', 'Lorem Ibsum', 1),
('verd_otonio', 'Verduras Primavera', 'Lorem Ibsum', 1),
('verd_prim', 'Verduras Primavera', 'Lorem Ibsum', 1),
('verd_retos', 'Juegos Verduras', 'Lorem Ibsum', 1),
('verd_verano', 'Verduras Primavera', 'Lorem Ibsum', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_contenido_usu`
--

CREATE TABLE `tbl_contenido_usu` (
  `id_cont` int(11) NOT NULL,
  `vc_email` varchar(60)   NOT NULL,
  `vc_nombreCont` varchar(60)   NOT NULL,
  `vc_descCont` int(255) DEFAULT NULL,
  `blb_contenido` longblob,
  `vc_extension` varchar(5)   DEFAULT NULL
) ENGINE=InnoDB  ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_rol`
--

CREATE TABLE `tbl_rol` (
  `id_rol` int(11) NOT NULL,
  `Nombre` varchar(128) NOT NULL,
  `Descripcion` varchar(255) NOT NULL
) ENGINE=InnoDB ;

--
-- Volcado de datos para la tabla `tbl_rol`
--

INSERT INTO `tbl_rol` (`id_rol`, `Nombre`, `Descripcion`) VALUES
(1, 'Paciente', 'Lorem Ibsum'),
(2, 'Especialista', 'Lorem Ibsum');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuarios`
--

CREATE TABLE `tbl_usuarios` (
  `id_usuario` int(11) NOT NULL,
  `vc_nombre` varchar(250) NOT NULL,
  `vc_apellido` varchar(250) NOT NULL,
  `vc_emaill` varchar(60) NOT NULL,
  `vc_password` varchar(160) NOT NULL,
  `vc_sexo` varchar(45) DEFAULT NULL,
  `int_edad` int(11) DEFAULT NULL,
  `id_rol` int(11) DEFAULT '1',
  `vc_peso` decimal(7,3) DEFAULT NULL,
  `vc_altura` decimal(7,3) DEFAULT NULL,
  `vc_imc` decimal(7,3) DEFAULT NULL,
  `vc_enfermedades` longtext,
  `vc_respuestasCuest` longtext,
  `img_foto` longblob,
  `bool_activo` tinyint(1) DEFAULT '1'
) ;

--
-- Volcado de datos para la tabla `tbl_usuarios`
--

INSERT INTO `tbl_usuarios` (`id_usuario`, `vc_nombre`, `vc_apellido`, `vc_emaill`, `vc_password`, `vc_sexo`, `int_edad`, `id_rol`, `vc_peso`, `vc_altura`, `vc_imc`, `vc_enfermedades`, `vc_respuestasCuest`, `img_foto`, `bool_activo`) VALUES
(20, 'Anita', 'Mandarina', 'anita.mandarina@demo.com', '84db7e84282fc7f704513db93ef912025fb54c66', 'Mujer', 22, 1, '59.200', '1.600', '10.000', '{\"rojo\":\"#f00\",\"verde\":\"#0f0\",\"azul\":\"#00f\",\"cyan\":\"#0ff\",\"magenta\":\"#f0f\",\"negro\":\"#000\"}', 'resp1-resp2-resp3-resp4', NULL, 1),
(21, 'Usuarios', 'Pruebas', 'pruebas.calori@kannbal.com', '9c9cc128e102ac2724d931dfb9890ce80a445bf6', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(22, 'Luis', 'Mejia', 'eduardo@gamil.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(23, 'Eduardo', 'Mejia', 'prueba@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(24, 'Kate', 'Mejia', 'kat@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(25, 'Popis', 'Mejia', 'popis@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(26, 'Daniel', 'Mejia', 'daniel@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(27, 'Daniela', 'Mejia', 'daniela@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(28, 'Raul', 'Mejia', 'raul@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(29, 'mafer', 'Mejia', 'mafer@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'null', NULL, 1, NULL, NULL, NULL, '[\"Diabetes\"]', NULL, NULL, 1),
(30, 'Saul', 'Torres', 'saul@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(31, 'Samuel', 'Torres', 'samuel@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(32, 'Juan', 'Gomez', 'juan@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'Hombre', 24, 1, '46.000', '160.000', NULL, '[\"Diabetes\"]', NULL, NULL, 1),
(33, 'Daniela', 'Mercado', 'dani@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'Hombre', 27, 1, '68.000', '175.000', NULL, '[\"Diabetes\"]', NULL, NULL, 1),
(34, 'Marcos ', 'Archundia ', 'marcos@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'Hombre', 78, 1, '25.000', '185.000', NULL, '[\"Diabetes\"]', NULL, NULL, 1),
(35, 'Alex', 'Bastida', 'alex@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'Hombre', 27, 1, '65.000', '175.000', '24.300', '[\"Diabetes\",\"Hepatitis A\"]', '[\"Canceres\"]', NULL, 1),
(36, 'Samuel', 'Torres', 'melissa@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'null', NULL, 1, NULL, NULL, '21.100', 'null', '[\"Embarazo\"]', NULL, 1),
(37, 'Usuarios', 'Pruebas', 'andres@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(38, 'Usuarios', 'Pruebas', 'andresa@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(39, 'Usuarios', 'Pruebas', 'pan@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(40, 'Juan ', 'Gomez', 'panes@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(41, 'Angel', 'Mejia', 'angel@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(42, 'Manuel', 'Mondragon', 'manu@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'Hombre', 26, 1, '65.000', '175.000', '21.200', '[\"Diabetes\"]', '[\"Embarazo\"]', NULL, 1),
(43, 'Botsito', 'Ramírez ', 'bot@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(44, 'Sergio', 'Rodríguez', 'sergio.rodriguez@kannbal.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'Hombre', 28, 1, '67.000', '172.000', '22.600', '[\"Ninguna\"]', '[\"Heridas\",\"Infecciones\",\"Embarazo\"]', NULL, 1),
(45, 'Prueba ', 'Son', 'son@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'Hombre', 27, 1, '67.000', '175.000', '21.900', '[\"Diabetes\"]', '[\"Heridas\"]', NULL, 1),
(46, 'Lizz', 'Midudev', 'liz@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'Mujer', 45, 1, '50.000', '155.000', '20.800', '[\"Diabetes\"]', '[\"Canceres\"]', NULL, 1),
(47, 'Midudev', 'Miquel', 'midu@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'Hombre', 34, 1, '78.000', '175.000', '25.500', '[\"Diabetes\"]', '[\"Embarazo\"]', NULL, 1),
(48, 'Luis', 'Mejia', 'bota@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(49, 'Sergio', 'Rodríguez', 'sergiiorod94@gmail.com', '94f78c82f08e12844edff5e1edc666b9a36aac7b', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(50, 'Prueba', 'Prueba', 'Prueba', '93301ada8177f4b7841620847f3d06d41febdd1d', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(51, 'luis', 'mejia', 'demora', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(52, 'Alfredo', 'Olivas', 'alfredo@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'Hombre', 45, 1, '80.000', '175.000', '26.100', '[\"Diabetes\"]', '[\"Embarazo\",\"Heridas\"]', NULL, 1),
(53, 'Sergio', 'Rosas', 'serch_rod@hotmail.com', '7c7ab61073a9f4ed0ec10f5e81b97da7631bcbea', 'Hombre', 28, 1, '168.000', '172.000', '23.000', '[\"Ninguna\"]', '[\"Canceres\"]', NULL, 1),
(54, 'Docoras', 'Mendez', 'doc.calori@kannbal.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(55, 'Sergio', 'Rosas', 'sergio.rod94@gmail.com', '7c7ab61073a9f4ed0ec10f5e81b97da7631bcbea', 'Hombre', 28, 1, '69.000', '172.000', '23.300', '[\"Ninguna\"]', '[\"Ninguna\"]', NULL, 1),
(56, 'Sergio', 'Rodríguez', 'prueba@kannbal.com', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Hombre', 28, 1, '69.000', '172.000', '23.300', '[\"Ninguna\"]', '[\"Ninguna\"]', NULL, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `rel_contestar`
--
ALTER TABLE `rel_contestar`
  ADD KEY `email_usuario` (`email_usuario`,`id_actividad`),
  ADD KEY `id_actividad` (`id_actividad`),
  ADD KEY `id_rol` (`id_rol`);

--
-- Indices de la tabla `tbl_actividad`
--
ALTER TABLE `tbl_actividad`
  ADD PRIMARY KEY (`id_actividad`);

--
-- Indices de la tabla `tbl_contenido_usu`
--
ALTER TABLE `tbl_contenido_usu`
  ADD PRIMARY KEY (`id_cont`),
  ADD KEY `vc_email` (`vc_email`);

--
-- Indices de la tabla `tbl_rol`
--
ALTER TABLE `tbl_rol`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `tbl_usuarios`
--
ALTER TABLE `tbl_usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `vc_emaill` (`vc_emaill`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_contenido_usu`
--
ALTER TABLE `tbl_contenido_usu`
  MODIFY `id_cont` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_rol`
--
ALTER TABLE `tbl_rol`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tbl_usuarios`
--
ALTER TABLE `tbl_usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `rel_contestar`
--
ALTER TABLE `rel_contestar`
  ADD CONSTRAINT `rel_contestar_ibfk_1` FOREIGN KEY (`email_usuario`) REFERENCES `tbl_usuarios` (`vc_emaill`) ON UPDATE CASCADE,
  ADD CONSTRAINT `rel_contestar_ibfk_2` FOREIGN KEY (`id_actividad`) REFERENCES `tbl_actividad` (`id_actividad`) ON UPDATE CASCADE,
  ADD CONSTRAINT `rel_contestar_ibfk_3` FOREIGN KEY (`id_rol`) REFERENCES `tbl_rol` (`id_rol`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_contenido_usu`
--
ALTER TABLE `tbl_contenido_usu`
  ADD CONSTRAINT `tbl_contenido_usu_ibfk_1` FOREIGN KEY (`vc_email`) REFERENCES `tbl_usuarios` (`vc_emaill`) ON UPDATE CASCADE;
COMMIT;
